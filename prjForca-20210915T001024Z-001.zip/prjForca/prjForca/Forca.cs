﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjForca
{
    class Forca
    {
        private string[] palavras;
        private int pos;
        public Forca(string[] palavras, int pos)
        {
            this.palavras = palavras;
            this.pos = pos;            
        }
        public void sortear()
        {
            Random sorteio = new Random();
            pos = sorteio.Next(palavras.Count());
        }
        public string devolvePalavra()
        {
            return palavras[pos];
        }
    }
}
