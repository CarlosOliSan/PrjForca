﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjForca
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Forca jogo;

        string[] lista = new string[]{
            "ROMA","CASCAVEL","AUTOMOVEL","CORITIBA","PERNAMBUCO","MORANGO",
            "OFTALMOLOGISTA","VACA","SPIDERMAN","CAPIVARA","JAGUATIRICA","ALFACE",
            "SOFA","GARFO","PRATO","CAVEIRA","PELE","CORTINA"
        };

        Label[] Letras;
        int tentativas = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            jogo = new Forca(lista, 0);
            jogo.sortear();
            DesenharPalavra(jogo.devolvePalavra());
        }

        private void DesenharPalavra(string p)
        {
            Letras = new Label[p.Length];

            int ph = 10; //Movimentação horizontal
            int pv = 10; //Movimentação Vertical

            for (int i = 0; i < Letras.Count(); i++)
            {
                Letras[i] = new Label();
                Letras[i].Text = "?";
                Letras[i].Width = 32;
                Letras[i].Height = 32;
                Letras[i].AutoSize = false;
                Letras[i].TextAlign = ContentAlignment.MiddleCenter;
                Letras[i].ForeColor = Color.Red;
                Letras[i].BackColor = Color.Black;
                //Letras[i].Image = Image.FromFile(Environment.CurrentDirectory + "\\abobora.png");
                Letras[i].BorderStyle = BorderStyle.Fixed3D;
                if (i % 10 == 0 && i != 0)
                {
                    pv += 37;
                    ph = 10;
                }
                Letras[i].Top = pv;
                Letras[i].Left = ph;          
                pnPalavra.Controls.Add(Letras[i]); //Nome do objeto. Controles. o que ser adicionado
                ph += 37;
                Letras[i].Show();
            }
        }

        private void btnJogar_Click(object sender, EventArgs e)
        {
            string letra = txtLetra.Text;
            DesenharLetra(letra);
            txtLetra.Clear();
            txtLetra.Focus();
        }

        private void DesenharLetra(string letra)
        {
            string p = jogo.devolvePalavra();
            bool achou = false; //Bool = sistema booleano

            for (int i = 0; i < Letras.Count(); i++)
            {
                if (p.Substring(i, 1).Equals(letra)) //Na posição i ser a letra digitada na variável letra
                {
                    Letras[i].Text = letra;
                    achou = true;
                }
            }
            if (achou == false)
            {
                tentativas++;
                DesenharBoneco();
            }
        }

        private void DesenharBoneco()
        {
            string caminho = Environment.CurrentDirectory + "\\forca" + tentativas.ToString() + ".png";
            pbEnforcado.Image = Image.FromFile(caminho);
        }

    }
}
