﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prjForca
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        Forca jogo;

        string[] lista;
        string[] dicas;

        Label[] Letras;
        int tentativas = 0;
        SoundPlayer som;

        private void Form1_Load(object sender, EventArgs e)
        {
            PreencherLista();
            jogo = new Forca(lista, 0);
            jogo.sortear();
            DesenharPalavra(jogo.devolvePalavra());
            som = new SoundPlayer();
            som.SoundLocation = Environment.CurrentDirectory + "\\fundosom.wav";
            som.PlayLooping();
        }

        private void PreencherLista()
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt"; //Pegar o caminho do arquivo
            StreamReader arquivo = new StreamReader(caminho); //Abrir o arquivo
            int qtd = File.ReadAllLines(caminho).Count(); //Contar quantas linhas tem o arquivo
            lista = new string[qtd];
            dicas = new string[qtd];

            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                string[] campos = linha.Split(';'); //Dividir a linha
                lista[i] = campos[0];
                dicas[i] = campos[1];
            }
            arquivo.Close();
        }

        private void DesenharPalavra(string p)
        {
            Letras = new Label[p.Length];

            int ph = 10; //Movimentação horizontal
            int pv = 10; //Movimentação Vertical

            for (int i = 0; i < Letras.Count(); i++)
            {
                Letras[i] = new Label();
                Letras[i].Text = "?";
                Letras[i].Width = 32;
                Letras[i].Height = 32;
                Letras[i].AutoSize = false;
                Letras[i].TextAlign = ContentAlignment.MiddleCenter;
                Letras[i].ForeColor = Color.Red;
                Letras[i].BackColor = Color.Black;
                Letras[i].BorderStyle = BorderStyle.Fixed3D;
                if (i % 10 == 0 && i != 0)
                {
                    pv += 37;
                    ph = 10;
                }
                Letras[i].Top = pv;
                Letras[i].Left = ph;          
                pnPalavra.Controls.Add(Letras[i]); //Nome do objeto. Controles. o que ser adicionado
                ph += 37;
                Letras[i].Show();
            }
        }

        private void btnJogar_Click(object sender, EventArgs e)
        {
            string letra = txtLetra.Text;
            DesenharLetra(letra);
            txtLetra.Clear();
            txtLetra.Focus();
        }

        private void DesenharLetra(string letra)
        {
            string p = jogo.devolvePalavra();
            bool achou = false; //Bool = sistema booleano

            if (lbLetrasDigitadas.Text.Contains(letra))
            {
                MessageBox.Show("Letra já digitada");
                return; //Sai do método
            }
            lbLetrasDigitadas.Text += letra + " ";

            for (int i = 0; i < Letras.Count(); i++)
            {
                if (p.Substring(i, 1).Equals(letra)) //Na posição i ser a letra digitada na variável letra
                {
                    Letras[i].Text = letra;
                    achou = true;
                }
            }
            if (achou == false)
            {
                tentativas++;
                DesenharBoneco();
            }
            if (tentativas == 6)
            {
                timer1.Enabled = false;
                MessageBox.Show("Você perdeu! A palavra era " + p);
                NovoJogo();
            }

            Vitoria(); //Gera uma nova função 
        }

        private void Vitoria()
        {
            string p = jogo.devolvePalavra();
            string tmp = "";

            foreach (Label item in Letras)
            {
                tmp += item.Text;
            }
            if (p.Equals(tmp))
            {
                timer1.Enabled = false;
                MessageBox.Show("Você venceu!");
                NovoJogo();
            }
        }

        private void NovoJogo()
        {
            tentativas = 0;
            pbEnforcado.Image = null; //limpa picturebox
            pnPalavra.Controls.Clear(); //Remove os labels
            jogo.sortear();
            DesenharPalavra(jogo.devolvePalavra());
            lbLetrasDigitadas.Text = "";
            timer1.Enabled = true;
            lbCronometro.Text = "80";
        }

        private void DesenharBoneco()
        {
            string caminho = Environment.CurrentDirectory + "\\forca" + tentativas.ToString() + ".png";
            pbEnforcado.Image = Image.FromFile(caminho);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int segundo = Int16.Parse(lbCronometro.Text); //Conversão do lbCronometro de texto para número
            segundo--; //Faz a variável ter um valor a menos
            lbCronometro.Text = segundo.ToString();
            if (segundo == 0)
            {
                timer1.Enabled = false; //Para o timer
                MessageBox.Show("TEMPO ESGOTADO! A Palavra era " + jogo.devolvePalavra());
                NovoJogo();
            }
            if (segundo % 2 == 0)
            {
                lbCronometro.ForeColor = Color.Gold;
            }
            else
            {
                lbCronometro.ForeColor = Color.White;
            }
            if (segundo <= 10)
            {
                lbCronometro.ForeColor = Color.Red;
            }
        }
    }
}
